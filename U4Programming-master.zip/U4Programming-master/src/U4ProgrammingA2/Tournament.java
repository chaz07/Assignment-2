package U4ProgrammingA2;

public class Tournament extends Event {

    public static void createTournament() {
    }

    public static void tournamentResults() {
    }
}
