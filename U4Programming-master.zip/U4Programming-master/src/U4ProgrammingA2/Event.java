package U4ProgrammingA2;

public class Event {

    protected static int singleOrFiveEvents = 1; /*this makes the event single or five*/

    protected static int individualOrTeam = 1; /*this makes the teams individual or team*/ 

    protected static int sportingOrAcademic = 1; /*this makes the event sporting or academic*/

    public static void registerForEvent() {  /*this allows a user to register for an event*/
    }

    public static int getEvents() {
        return singleOrFiveEvents;
    }

    public static void individualOrTeam() {
    }

    public static void updateScore() {
    }
}
