package U4ProgrammingA2;

public interface Actions {

    public void add(); /*adds players to a team*/

    public void view(); 

    public void remove(); /*removes a player, team or event*/

    public void setFirstName(); /*adds the first name of a player*/

    public void setLastName(); /*adds the last name of a player

    public void setTeam(); /*this sets a team*/

    public void addToArrayList();
}
