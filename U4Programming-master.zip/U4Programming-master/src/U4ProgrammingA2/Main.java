package U4ProgrammingA2;

public class Main {

    private static int input;

    public static void main(String[] args) { /*this makes the menu event a string, meaning the input can be letters*/
        Menu.eventType();
    }
}
