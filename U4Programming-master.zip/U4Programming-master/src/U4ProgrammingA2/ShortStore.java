package U4ProgrammingA2;

import java.util.ArrayList;
import java.util.List;

public class ShortStore {

    protected static List<String> listPlayer = new ArrayList(); /*this allows a user to add more than one name*/

    protected static List<String> listTeam = new ArrayList(); /*this allows a user to add more than one team*/
}
